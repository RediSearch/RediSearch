import sys,time,json,subprocess,socket,os,re,hashlib
from pathlib import Path
import redis
BASE=Path('/tmp/mod19005-tip-profile')
ENGINE='/home/ubuntu/workspace/redis-unstable/src/redis-server'
LOADGEN='/home/ubuntu/workspace/search-workload-repro/loadgen/target/release/search-loadgen'
PORTS=list(range(7401,7407))
def clients():return [redis.Redis(host='127.0.0.1',port=p,decode_responses=True,socket_timeout=130) for p in PORTS]
def stop():
 for p,c in zip(PORTS,clients()):
  try:
   assert c.config_get('dir')['dir']==str(BASE/f'node{p}'),f'Foreign server on {p}'
   subprocess.run(['/home/ubuntu/workspace/redis-unstable/src/redis-cli','-p',str(p),'SHUTDOWN','NOSAVE'],check=True)
  except redis.ConnectionError:pass
 for _ in range(30):
  if all(not is_open(p) for p in PORTS):return
  time.sleep(1)
 raise RuntimeError('Our servers did not stop')
def is_open(p):
 s=socket.socket();s.settimeout(.2)
 try:s.connect(('127.0.0.1',p));return True
 except OSError:return False
 finally:s.close()
def start(module):
 module=str(Path(module).resolve()); assert Path(module).is_file()
 for p in PORTS+[p+10000 for p in PORTS]:assert not is_open(p),f'Port busy {p}'
 for p in PORTS:
  d=BASE/f'node{p}'
  cmd=[ENGINE,'--port',str(p),'--bind','127.0.0.1','--dir',str(d),'--daemonize','yes','--pidfile',str(d/'redis.pid'),'--cluster-enabled','yes','--cluster-config-file','nodes.conf','--cluster-node-timeout','10000','--appendonly','no','--save','','--dbfilename','dump.rdb','--logfile',str(d/'redis.log'),'--enable-debug-command','yes','--enable-module-command','yes','--protected-mode','yes','--maxmemory','0','--loadmodule',module,'WORKERS','4','MIN_OPERATION_WORKERS','4','TIMEOUT','0','CURSOR_MAX_IDLE','2000','INDEX_CURSOR_LIMIT','2000','WORKERS_PRIORITY_BIAS_THRESHOLD','6','BM25STD_TANH_FACTOR','200','DEFAULT_DIALECT','2','MAXPREFIXEXPANSIONS','1024','--search-io-threads','1']
  subprocess.run(cmd,check=True)
 for p,c in zip(PORTS,clients()):
  for _ in range(180):
   try:
    mods=c.execute_command('MODULE','LIST');assert module in str(mods),f'Module mismatch {p}: {mods}'
    assert c.config_get('dir')['dir']==str(BASE/f'node{p}')
    if c.cluster('info')['cluster_state']=='ok':break
   except (redis.ConnectionError,redis.BusyLoadingError):pass
   time.sleep(1)
  else:raise RuntimeError(f'{p} failed to load/join')
  c.execute_command('search.CLUSTERREFRESH')
  c.config_set('search-enable-unstable-features','yes');c.config_set('search-on-timeout','RETURN')
 total=sum(c.dbsize() for c in clients());assert total==5700001,f'Dataset count {total}'
 v=clients()[0].execute_command('FT.INFO','idx:bench');info=dict(zip(v[::2],v[1::2]));assert info['num_docs']==5700000 and info['indexing']==0 and info['hash_indexing_failures']==0,info
 print(f'Cluster ready: {total} keys, module={module}',flush=True)
 time.sleep(10)
def snapshot():
 return [{'port':p,'server':c.info('server'),'module':c.execute_command('MODULE','LIST'),'config':c.config_get('search-*'),'dbsize':c.dbsize(),'info':c.execute_command('FT.INFO','idx:bench'),'stats':c.info('stats'),'cpu':c.info('cpu')} for p,c in zip(PORTS,clients())]
def run(arm,fmt=None):
 if fmt:
  for c in clients():c.config_set('search-internal-row-block-format',fmt)
 cmd=[LOADGEN,'profile','--config',str(BASE/'config.toml'),'--term','term00*|term01*','--timeout-ms','120000','--plain']
 with (BASE/'logs'/f'{arm}-warmup.log').open('w') as f:subprocess.run(cmd+['--repeat','1'],stdout=f,stderr=subprocess.STDOUT,check=True)
 before=snapshot();t=time.time();cpu_before=Path('/proc/stat').read_text().splitlines()[0]
 with (BASE/'logs'/f'{arm}.log').open('w') as f:subprocess.run(cmd+['--repeat','5','--require-quiet','0.20'],stdout=f,stderr=subprocess.STDOUT,check=True)
 after=snapshot()
 result=clients()[0].execute_command(*json.loads((BASE/'query.json').read_text()))
 assert len(result)==401,f'Expected 400 groups, got {len(result)-1}'
 (BASE/'logs'/f'{arm}-rows.json').write_text(json.dumps(result,indent=2))
 metadata={'arm':arm,'elapsed':time.time()-t,'command':cmd,'before':before,'after':after,'cpu_before':cpu_before,'cpu_after':Path('/proc/stat').read_text().splitlines()[0]}
 (BASE/'logs'/f'{arm}-metadata.json').write_text(json.dumps(metadata,indent=2))
 wire=sum(j['stats']['total_net_output_bytes']-i['stats']['total_net_output_bytes'] for i,j in zip(before[1:],after[1:]))/5
 if fmt=='yes':assert wire<100000000,f'Treatment did not reduce wire volume: {wire}'
 log=(BASE/'logs'/f'{arm}.log').read_text();print('\n'.join(l for l in log.splitlines() if l.startswith(('run ','===','machine','load average'))),flush=True)
if __name__=='__main__':
 if sys.argv[1]=='start':start(sys.argv[2])
 elif sys.argv[1]=='stop':stop()
 elif sys.argv[1]=='run':run(*sys.argv[2:])
